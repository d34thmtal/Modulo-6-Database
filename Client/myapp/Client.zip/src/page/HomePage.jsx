
import React from 'react'
import Post from '../components/Post'

export default function HomePage() {
    return (
        <Post />
    )
}
